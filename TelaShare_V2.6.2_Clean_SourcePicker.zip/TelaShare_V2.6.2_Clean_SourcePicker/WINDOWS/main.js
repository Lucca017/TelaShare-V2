const {app,BrowserWindow,session,desktopCapturer,ipcMain,shell}=require('electron');
const path=require('path');
const SITE=process.env.TELASHARE_URL||'https://telashare-v2.onrender.com';
let win=null,selected=null;

async function sources(){
 return desktopCapturer.getSources({
  types:['screen','window'],
  thumbnailSize:{width:256,height:144},
  fetchWindowIcons:false
 });
}

function setupIPC(){
 ipcMain.handle('ts:sources',async()=> (await sources()).map(s=>({
  id:s.id,name:s.name,type:s.id.startsWith('screen:')?'screen':'window',
  thumbnail:s.thumbnail&&!s.thumbnail.isEmpty()?s.thumbnail.toDataURL():null,
  icon:s.appIcon&&!s.appIcon.isEmpty()?s.appIcon.toDataURL():null
 })));
 ipcMain.handle('ts:select',(_,id)=>{selected=id||null;return true});
 ipcMain.handle('ts:selected',()=>selected);
 ipcMain.handle('ts:autostart',(_,enabled)=>{
  app.setLoginItemSettings({openAtLogin:!!enabled,path:process.execPath});
  return app.getLoginItemSettings().openAtLogin;
 });
 ipcMain.handle('ts:get-autostart',()=>app.getLoginItemSettings().openAtLogin);
 ipcMain.handle('ts:minimize',()=>{win?.minimize();return true});
}

function setupCapture(){
 session.defaultSession.setDisplayMediaRequestHandler(async(req,callback)=>{
  try{
   const list=await sources();
   let source=list.find(s=>s.id===selected);
   if(!source) source=list.find(s=>s.id.startsWith('screen:'))||list[0];
   if(!source)return callback({});
   const grant={video:source};
   if(req.audioRequested)grant.audio='loopback';
   callback(grant);
  }catch(e){console.error('Captura:',e);callback({})}
 });
 session.defaultSession.setPermissionCheckHandler((_wc,p,origin)=>{
  if(!origin.startsWith(SITE))return false;
  return ['media','display-capture','fullscreen'].includes(p);
 });
 session.defaultSession.setPermissionRequestHandler((wc,p,cb,details)=>{
  const origin=details?.requestingUrl||wc.getURL();
  cb(origin.startsWith(SITE)&&['media','display-capture','fullscreen'].includes(p));
 });
}

function create(){
 win=new BrowserWindow({
  width:1600,height:960,minWidth:1100,minHeight:720,
  backgroundColor:'#050b13',autoHideMenuBar:true,title:'TelaShare V2.6 Lite',show:false,
  webPreferences:{
   preload:path.join(__dirname,'preload.js'),
   contextIsolation:true,nodeIntegration:false,sandbox:false,spellcheck:false
  }
 });
 win.webContents.setWindowOpenHandler(({url})=>{
  if(url.startsWith(SITE))return{action:'allow'};
  shell.openExternal(url);return{action:'deny'};
 });
 win.once('ready-to-show',()=>win.show());
 win.loadURL(SITE).catch(()=>win.loadFile('offline.html'));
 win.webContents.on('did-fail-load',(_e,_c,_d,_url,isMain)=>{
  if(isMain)win.loadFile('offline.html');
 });
}

app.whenReady().then(()=>{
 setupIPC();setupCapture();create();
 app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)create()});
});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit()});
