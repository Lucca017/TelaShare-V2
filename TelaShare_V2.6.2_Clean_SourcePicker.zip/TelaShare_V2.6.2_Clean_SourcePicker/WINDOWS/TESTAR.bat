@echo off
title TelaShare Windows V2.0 - Teste
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
 echo Instale o Node.js LTS primeiro.
 pause
 exit /b 1
)
if not exist node_modules call npm install
call npm start
pause
