const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('TSDesktop',{
 sources:()=>ipcRenderer.invoke('ts:sources'),
 select:id=>ipcRenderer.invoke('ts:select',id),
 selected:()=>ipcRenderer.invoke('ts:selected'),
 autostart:v=>ipcRenderer.invoke('ts:autostart',v),
 getAutostart:()=>ipcRenderer.invoke('ts:get-autostart'),
 minimize:()=>ipcRenderer.invoke('ts:minimize')
});
