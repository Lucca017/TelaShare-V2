@echo off
title TelaShare Windows V2.0 - Gerar Instalador
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
 echo Instale o Node.js LTS primeiro.
 pause
 exit /b 1
)
if exist node_modules rmdir /s /q node_modules
if exist package-lock.json del /q package-lock.json
call npm install
if errorlevel 1 goto erro
call npm run dist
if errorlevel 1 goto erro
echo.
echo ==========================================
echo  PRONTO! Instalador criado na pasta dist
echo ==========================================
pause
exit /b
:erro
echo.
echo Ocorreu um erro. Envie um print desta janela.
pause
